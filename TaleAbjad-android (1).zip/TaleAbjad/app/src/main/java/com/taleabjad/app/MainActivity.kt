package com.taleabjad.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

enum class Route { Home, Numbers, Marriage, Astrology, Saved, Soon }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                TaleTheme { App() }
            }
        }
    }
}

@Composable
fun App() {
    var route by remember { mutableStateOf(Route.Home) }
    BackHandler(enabled = route != Route.Home) { route = Route.Home }
    val back = { route = Route.Home }
    val saved = { route = Route.Saved }
    when (route) {
        Route.Home -> HomeScreen { route = it }
        Route.Numbers -> NumbersScreen(back, saved)
        Route.Marriage -> MarriageScreen(back, saved)
        Route.Astrology -> AstrologyScreen(back, saved)
        Route.Saved -> SavedScreen(back)
        Route.Soon -> SoonScreen(back, saved)
    }
}
