package com.taleabjad.app

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class ResultData(val kind: String, val lines: List<String>)

private val PinkC = listOf(Color(0xFFE0197D), Color(0xFF8F0F6B))
private val BlueC = listOf(Color(0xFF7B4DFF), Color(0xFF3A1FA8))

@Composable
fun ResultHost(result: ResultData?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var saved by remember(result) { mutableStateOf(false) }
    if (result != null) {
        GlassDialog(result.kind, result.lines, saved, onSave = {
            SavedStore.add(ctx, result.kind, result.lines)
            saved = true
            Toast.makeText(ctx, "ذخیره شد", Toast.LENGTH_SHORT).show()
        }, onDismiss = onClose)
    }
}

@Composable
fun HomeScreen(go: (Route) -> Unit) {
    ScreenFrame("طالع ابجد", null, { go(Route.Saved) }) {
        Text("فال، طالع و تفأل بر پایه حساب ابجد", color = Sub, fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 4.dp))
        MenuCard("بخش کاربردی اعداد ابجد", "معانی و تعبیر اعداد ابجد", Color(0xFFFDE6C8), { go(Route.Numbers) }) {
            Image(painterResource(R.drawable.icon_books), null, Modifier.size(64.dp))
        }
        MenuCard("فال ازدواج ابجدی", "سنجش تفأل و همدلی دو نام", Color(0xFFF9BFDC), { go(Route.Marriage) }) {
            GradientIcon(PinkC, Icons.Filled.Favorite)
        }
        MenuCard("طالع بینی ابجدی", "طالع و ستاره شما بر پایه نام", Color(0xFFCFB8FB), { go(Route.Astrology) }) {
            GradientIcon(BlueC, Icons.Filled.Star)
        }
        Image(painterResource(R.drawable.banner_quran), "استخاره قرآن کریم",
            Modifier.fillMaxWidth().shadow(6.dp, RoundedCornerShape(20.dp)).clip(RoundedCornerShape(20.dp))
                .clickable { go(Route.Soon) },
            contentScale = ContentScale.FillWidth)
        MenuCard("دیگر برنامه های گروه", "برنامه های متنوع و جذاب", Color(0xFFB9ECC4), { go(Route.Soon) }) {
            Image(painterResource(R.drawable.icon_basket), null, Modifier.size(64.dp))
        }
    }
}

@Composable
fun MarriageScreen(onBack: () -> Unit, onSaved: () -> Unit) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ResultData?>(null) }
    ScreenFrame("فال ازدواج ابجدی", onBack, onSaved, blurred = result != null) {
        IntroCard(PinkC, Icons.Filled.Favorite, "سنجش تفأل و همدلی", "نام خود و همسر آینده‌تان را وارد کنید")
        FormCard {
            TaleField(a, "نام شما", Icons.Filled.Person, err && Abjad.value(a) == 0) { a = it }
            TaleField(b, "نام همسر آینده", Icons.Filled.Person, err && Abjad.value(b) == 0) { b = it }
            TaleButton("محاسبه فال", Icons.Filled.Favorite) {
                err = true
                val va = Abjad.value(a); val vb = Abjad.value(b)
                if (va > 0 && vb > 0) {
                    val za = Abjad.zodiac(va); val zb = Abjad.zodiac(vb)
                    result = ResultData("فال ازدواج ابجدی", listOf(
                        "${a.trim()}: $va ← برج ${za.name}، عنصر ${Abjad.elements[za.element]}",
                        "${b.trim()}: $vb ← برج ${zb.name}، عنصر ${Abjad.elements[zb.element]}",
                        "مجموع ابجد دو نام: ${va + vb}",
                        Abjad.compatibility(za.element, zb.element)
                    ))
                }
            }
        }
        Note()
    }
    ResultHost(result) { result = null }
}

@Composable
fun AstrologyScreen(onBack: () -> Unit, onSaved: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var mother by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ResultData?>(null) }
    ScreenFrame("طالع بینی ابجدی", onBack, onSaved, blurred = result != null) {
        IntroCard(BlueC, Icons.Filled.Star, "طالع و ستاره شما", "نام خود و نام مادر را وارد کنید")
        FormCard {
            TaleField(name, "نام شما", Icons.Filled.Person, err && Abjad.value(name) == 0) { name = it }
            TaleField(mother, "نام مادر", Icons.Filled.Person, err && Abjad.value(mother) == 0) { mother = it }
            TaleButton("محاسبه طالع", Icons.Filled.Star) {
                err = true
                val v1 = Abjad.value(name); val v2 = Abjad.value(mother)
                if (v1 > 0 && v2 > 0) {
                    val z = Abjad.zodiac(v1 + v2)
                    result = ResultData("طالع بینی ابجدی", listOf(
                        "${name.trim()} و ${mother.trim()}",
                        "مجموع ابجد: ${v1 + v2}",
                        "برج: ${z.name}",
                        "عنصر: ${Abjad.elements[z.element]}",
                        "ویژگی: ${z.trait}"
                    ))
                }
            }
        }
        Note()
    }
    ResultHost(result) { result = null }
}

@Composable
fun NumbersScreen(onBack: () -> Unit, onSaved: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ResultData?>(null) }
    ScreenFrame("اعداد ابجد", onBack, onSaved, blurred = result != null) {
        IntroCard(listOf(Color(0xFFF59E0B), Color(0xFFB45309)), Icons.Filled.Search,
            "معنای عدد ابجد", "نام یا کلمه را وارد کنید")
        FormCard {
            TaleField(text, "نام یا کلمه", Icons.Filled.Person, err && Abjad.value(text) == 0) { text = it }
            TaleButton("محاسبه عدد ابجد", Icons.Filled.Search) {
                err = true
                val v = Abjad.value(text)
                if (v > 0) {
                    val r = Abjad.reduce(v)
                    result = ResultData("اعداد ابجد", listOf(
                        text.trim(), "عدد ابجد: $v", "عدد تقلیل‌یافته: $r", "معنا: ${Abjad.numberMeaning[r]}"
                    ))
                }
            }
        }
        Note()
    }
    ResultHost(result) { result = null }
}

@Composable
fun SavedScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val items = remember { mutableStateListOf<SavedItem>().apply { addAll(SavedStore.load(ctx)) } }
    ScreenFrame("ذخیره‌شده‌ها", onBack, null) {
        if (items.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(top = 60.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(BookmarkIcon, null, tint = Purple.copy(alpha = 0.4f), modifier = Modifier.size(64.dp))
                Spacer(Modifier.height(12.dp))
                Text("هنوز چیزی ذخیره نکرده‌اید", color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("نتیجه فال یا طالع را با دکمه ذخیره نگه دارید", color = Sub, fontSize = 13.sp,
                    textAlign = TextAlign.Center)
            }
        } else {
            items.toList().forEach { item ->
                val shape = RoundedCornerShape(20.dp)
                Column(Modifier.fillMaxWidth().shadow(4.dp, shape).clip(shape).background(Color.White).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(item.kind, color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
                            modifier = Modifier.weight(1f))
                        IconButton(onClick = {
                            SavedStore.remove(ctx, item.id)
                            items.removeAll { it.id == item.id }
                        }) { Icon(Icons.Filled.Delete, "حذف", tint = Color(0xFFB3261E)) }
                    }
                    item.lines.forEach { Text(it, color = Ink, fontSize = 14.sp, lineHeight = 22.sp) }
                }
            }
        }
    }
}

@Composable
fun SoonScreen(onBack: () -> Unit, onSaved: () -> Unit) {
    ScreenFrame("به‌زودی", onBack, onSaved) {
        FormCard {
            Text("این بخش در حال آماده‌سازی است", color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
            Text("در نسخه‌های بعدی اضافه می‌شود.", color = Sub, fontSize = 14.sp)
        }
    }
}
