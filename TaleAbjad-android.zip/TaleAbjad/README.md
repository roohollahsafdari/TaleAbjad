# طالع ابجد (Android)
1. پوشه را در یک ریپوی GitHub آپلود کنید (branch: main).
2. تب Actions ← Build APK ← Run workflow (یا با هر push خودکار اجرا می‌شود).
3. پس از اتمام، از بخش Artifacts فایل TaleAbjad-debug-apk را دانلود کنید؛ داخلش app-debug.apk است.
