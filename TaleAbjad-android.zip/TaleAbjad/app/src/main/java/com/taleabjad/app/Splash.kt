package com.taleabjad.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

/** Lives as long as the app process: entrance animations play only once per app launch. */
object Session {
    var homeAnimated = false
    var contactAnimated = false
}

@Composable
fun Staggered(index: Int, animate: Boolean, step: Int = 80, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(!animate) }
    LaunchedEffect(Unit) { shown = true }
    val a by animateFloatAsState(
        if (shown) 1f else 0f,
        tween(450, delayMillis = if (animate) 120 + index * step else 0, easing = FastOutSlowInEasing),
        label = "staggered"
    )
    Box(Modifier.graphicsLayer {
        alpha = a
        translationY = (1f - a) * -36.dp.toPx()
        val sc = 0.94f + 0.06f * a
        scaleX = sc
        scaleY = sc
    }) { content() }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        show = true
        delay(2000)
        onDone()
    }
    val rings by animateFloatAsState(if (show) 1f else 0f, tween(1100, easing = FastOutSlowInEasing), label = "rings")
    val logoA by animateFloatAsState(if (show) 1f else 0f, tween(700), label = "logoA")
    val logoS by animateFloatAsState(
        if (show) 1f else 0f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "logoS"
    )
    val title by animateFloatAsState(if (show) 1f else 0f, tween(600, 350, FastOutSlowInEasing), label = "title")
    val sub by animateFloatAsState(if (show) 1f else 0f, tween(600, 600, FastOutSlowInEasing), label = "sub")
    val tag by animateFloatAsState(if (show) 1f else 0f, tween(600, 850, FastOutSlowInEasing), label = "tag")

    Box(
        Modifier.fillMaxSize().background(Brush.linearGradient(listOf(PurpleDark, PurpleLight))),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height * 0.41f)
            drawCircle(
                Brush.radialGradient(listOf(Gold.copy(alpha = 0.35f * logoA), Color.Transparent), center = c, radius = size.width * 0.45f),
                radius = size.width * 0.45f, center = c
            )
            for (i in 1..5) {
                val r = size.width * 0.18f * i * (0.6f + 0.4f * rings)
                drawCircle(
                    Gold.copy(alpha = (0.30f - i * 0.04f).coerceAtLeast(0.04f) * rings),
                    radius = r, center = c, style = Stroke(width = 1.5.dp.toPx())
                )
            }
            val rnd = Random(5)
            repeat(60) {
                drawCircle(
                    Gold.copy(alpha = (0.25f + rnd.nextFloat() * 0.5f) * rings),
                    radius = (0.8f + rnd.nextFloat() * 2f).dp.toPx(),
                    center = Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                bitmap = ImageBitmap.imageResource(R.drawable.logo_hd), contentDescription = null,
                filterQuality = FilterQuality.High,
                modifier = Modifier.size(150.dp).graphicsLayer {
                    alpha = logoA
                    val s = 0.4f + 0.6f * logoS
                    scaleX = s
                    scaleY = s
                    rotationZ = (1f - logoS) * -120f
                }
            )
            Spacer(Modifier.height(26.dp))
            Text(
                "طالع ابجد", color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.graphicsLayer { alpha = title; translationY = (1f - title) * 40.dp.toPx() }
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "فال ازدواج • طالع بینی • محاسبه ابجد نام", color = Color(0xFFFFE28A), fontSize = 15.sp,
                fontWeight = FontWeight.Medium, textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = sub; translationY = (1f - sub) * 30.dp.toPx() }
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "بر پایه حساب ابجد و علم حروف", color = Color(0xFFEBDDFB), fontSize = 13.sp,
                modifier = Modifier.graphicsLayer { alpha = tag }
            )
        }
    }
}
