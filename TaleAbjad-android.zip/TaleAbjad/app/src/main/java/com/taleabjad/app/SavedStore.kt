package com.taleabjad.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SavedItem(val id: Long, val kind: String, val lines: List<String>)

object SavedStore {
    private fun prefs(c: Context) = c.getSharedPreferences("saved", Context.MODE_PRIVATE)

    fun load(c: Context): List<SavedItem> {
        val arr = try { JSONArray(prefs(c).getString("items", "[]")) } catch (e: Exception) { JSONArray() }
        val out = ArrayList<SavedItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val l = o.getJSONArray("lines")
            val lines = ArrayList<String>()
            for (j in 0 until l.length()) lines.add(l.getString(j))
            out.add(SavedItem(o.getLong("id"), o.getString("kind"), lines))
        }
        return out
    }

    private fun write(c: Context, list: List<SavedItem>) {
        val arr = JSONArray()
        for (s in list) {
            arr.put(JSONObject().put("id", s.id).put("kind", s.kind).put("lines", JSONArray(s.lines)))
        }
        prefs(c).edit().putString("items", arr.toString()).apply()
    }

    fun add(c: Context, kind: String, lines: List<String>) {
        write(c, listOf(SavedItem(System.currentTimeMillis(), kind, lines)) + load(c))
    }

    fun remove(c: Context, id: Long) {
        write(c, load(c).filter { it.id != id })
    }
}
