package com.taleabjad.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private fun vec(name: String, d: String): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f)
        .addPath(PathParser().parsePathString(d).toNodes(), fill = SolidColor(Color.Black)).build()

val BookmarkIcon: ImageVector by lazy {
    vec("bookmark", "M17,3H7c-1.1,0 -1.99,0.9 -1.99,2L5,21l7,-3 7,3V5c0,-1.1 -0.9,-2 -2,-2z")
}
val SchoolIcon: ImageVector by lazy {
    vec("school", "M5,13.18v4L12,21l7,-3.82v-4L12,17l-7,-3.82zM12,3L1,9l11,6 9,-4.91V17h2V9L12,3z")
}

@Composable
fun TaleNavBar(current: Route, onSelect: (Route) -> Unit) {
    val colors = NavigationBarItemDefaults.colors(
        selectedIconColor = Purple, selectedTextColor = Purple, indicatorColor = Color(0xFFEBDDFB),
        unselectedIconColor = Sub, unselectedTextColor = Sub
    )
    NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
        NavigationBarItem(current == Route.Home, { onSelect(Route.Home) },
            { Icon(Icons.Filled.Home, null) }, label = { Text("خانه") }, colors = colors)
        NavigationBarItem(current == Route.Education, { onSelect(Route.Education) },
            { Icon(SchoolIcon, null) }, label = { Text("آموزش") }, colors = colors)
        NavigationBarItem(current == Route.Contact, { onSelect(Route.Contact) },
            { Icon(Icons.Filled.Email, null) }, label = { Text("ارتباط با ما") }, colors = colors)
    }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?, onSaved: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().height(64.dp).shadow(4.dp)
            .background(Brush.horizontalGradient(listOf(PurpleDark, PurpleLight)))
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت", tint = Color.White)
            }
        } else {
            Image(painterResource(R.drawable.logo), null, Modifier.padding(start = 12.dp).size(42.dp))
        }
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp))
        if (onSaved != null) {
            IconButton(onClick = onSaved) {
                Icon(BookmarkIcon, "ذخیره‌شده‌ها", tint = Color.White)
            }
        }
    }
}

@Composable
fun BoxScope.BottomDecor() {
    Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(300.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0x334A1480))))
            val c = Offset(size.width / 2f, size.height * 0.95f)
            for (i in 1..5) {
                drawCircle(Gold.copy(alpha = 0.34f - i * 0.05f), radius = size.width * 0.13f * i,
                    center = c, style = Stroke(width = 1.5.dp.toPx()))
            }
            for (k in 0 until 24) {
                val a = Math.toRadians(k * 15.0)
                val r1 = size.width * 0.13f
                val r2 = size.width * 0.65f
                drawLine(Gold.copy(alpha = 0.2f),
                    Offset(c.x + (r1 * cos(a)).toFloat(), c.y - (r1 * sin(a)).toFloat()),
                    Offset(c.x + (r2 * cos(a)).toFloat(), c.y - (r2 * sin(a)).toFloat()),
                    strokeWidth = 1.dp.toPx())
            }
            val rnd = Random(7)
            repeat(28) {
                drawCircle(Gold.copy(alpha = 0.4f), radius = (0.8f + rnd.nextFloat() * 1.8f).dp.toPx(),
                    center = Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height * 0.75f))
            }
        }
        Image(painterResource(R.drawable.logo), null,
            Modifier.align(Alignment.BottomCenter).offset(y = 60.dp).size(210.dp).alpha(0.22f))
    }
}

@Composable
fun ScreenFrame(
    title: String, onBack: (() -> Unit)?, onSaved: (() -> Unit)?,
    blurred: Boolean = false, content: @Composable ColumnScope.() -> Unit
) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg, Color(0xFFE9E0F7))))) {
        BottomDecor()
        Column(Modifier.fillMaxSize().blur(if (blurred) 12.dp else 0.dp)) {
            TopBar(title, onBack, onSaved)
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp), content = content
            )
        }
    }
}

@Composable
fun GradientIcon(colors: List<Color>, icon: ImageVector, size: Int = 64) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(Brush.linearGradient(colors)),
        contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size((size / 2).dp))
    }
}

@Composable
fun MenuCard(title: String, sub: String, tint: Color, onClick: () -> Unit, icon: @Composable () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier.fillMaxWidth().shadow(6.dp, shape).clip(shape)
            .background(Brush.horizontalGradient(0f to tint, 0.45f to Color.White))
            .clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(Modifier.width(12.dp))
        Box(Modifier.width(1.dp).height(48.dp).background(Color(0x334A1480)))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
            Text(sub, color = Sub, fontSize = 12.sp)
        }
        Box(Modifier.size(36.dp).clip(CircleShape).background(Purple), contentAlignment = Alignment.Center) {
            Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = Color.White, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
fun IntroCard(colors: List<Color>, icon: ImageVector, title: String, text: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        GradientIcon(colors, icon, 56)
        Column(Modifier.padding(horizontal = 12.dp)) {
            Text(title, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Text(text, color = Sub, fontSize = 13.sp)
        }
    }
}

@Composable
fun FormCard(content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.fillMaxWidth().shadow(6.dp, shape).clip(shape).background(Color.White).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
}

@Composable
fun TaleField(value: String, label: String, icon: ImageVector, error: Boolean, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        label = { Text(label) },
        leadingIcon = { Icon(icon, null) },
        singleLine = true, isError = error,
        supportingText = if (error) { { Text("نام را با حروف فارسی وارد کنید") } } else null,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Purple, focusedLabelColor = Purple, cursorColor = Purple,
            focusedLeadingIconColor = Purple,
            focusedContainerColor = Color.White, unfocusedContainerColor = Color(0xFFFAF7FF)
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun TaleButton(text: String, icon: ImageVector, onClick: () -> Unit) {
    Button(
        onClick, Modifier.fillMaxWidth().height(54.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Purple),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
    ) {
        Icon(icon, null, Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Note() = Text("این برنامه جنبه سرگرمی و فرهنگی دارد و جایگزین مشاوره نیست.",
    color = Sub, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())

@Composable
fun GlassDialog(kind: String, lines: List<String>, saved: Boolean, onSave: () -> Unit, onDismiss: () -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().clip(shape)
                .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.88f), Color(0xFFEBDDFB).copy(alpha = 0.78f))))
                .border(1.dp, Color.White.copy(alpha = 0.85f), shape)
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Star, null, tint = Gold, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(8.dp))
                Text(kind, color = Purple, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x334A1480)))
            Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                lines.forEach { Text(it, color = Ink, fontSize = 15.sp, lineHeight = 24.sp) }
            }
            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onSave, Modifier.weight(1f).height(48.dp), enabled = !saved,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                    Icon(BookmarkIcon, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (saved) "ذخیره شد" else "ذخیره")
                }
                OutlinedButton(onDismiss, Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp)) {
                    Text("بستن", color = Purple)
                }
            }
        }
    }
}
