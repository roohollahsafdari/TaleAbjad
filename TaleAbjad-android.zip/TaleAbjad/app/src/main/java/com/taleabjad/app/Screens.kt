package com.taleabjad.app

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class ResultData(val kind: String, val lines: List<String>)

private val PinkC = listOf(Color(0xFFE0197D), Color(0xFF8F0F6B))
private val BlueC = listOf(Color(0xFF7B4DFF), Color(0xFF3A1FA8))

@Composable
fun ResultHost(result: ResultData?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var saved by remember(result) { mutableStateOf(false) }
    if (result != null) {
        GlassDialog(result.kind, result.lines, saved, onSave = {
            SavedStore.add(ctx, result.kind, result.lines)
            saved = true
            Toast.makeText(ctx, "ذخیره شد", Toast.LENGTH_SHORT).show()
        }, onDismiss = onClose)
    }
}

@Composable
fun HomeScreen(go: (Route) -> Unit) {
    ScreenFrame("طالع ابجد", null, { go(Route.Saved) }) {
        Text("فال، طالع و تفأل بر پایه حساب ابجد", color = Sub, fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 4.dp))
        MenuCard("محاسبه ی ابجد نام", "معانی و تعبیر اعداد ابجد", Color(0xFFFDE6C8), { go(Route.Numbers) }) {
            Image(painterResource(R.drawable.icon_books), null, Modifier.size(64.dp))
        }
        MenuCard("فال ازدواج ابجدی", "جفت بودن ستاره ها و نام ها", Color(0xFFF9BFDC), { go(Route.Marriage) }) {
            GradientIcon(PinkC, Icons.Filled.Favorite)
        }
        MenuCard("طالع بینی ابجدی", "طالع و ستاره شما بر پایه نام", Color(0xFFCFB8FB), { go(Route.Astrology) }) {
            GradientIcon(BlueC, Icons.Filled.Star)
        }
        Image(painterResource(R.drawable.banner_quran), "استخاره قرآن کریم",
            Modifier.fillMaxWidth().shadow(6.dp, RoundedCornerShape(20.dp)).clip(RoundedCornerShape(20.dp))
                .clickable { go(Route.Soon) },
            contentScale = ContentScale.FillWidth)
        MenuCard("دیگر برنامه های گروه", "برنامه های متنوع و جذاب", Color(0xFFB9ECC4), { go(Route.Soon) }) {
            Image(painterResource(R.drawable.icon_basket), null, Modifier.size(64.dp))
        }
    }
}

@Composable
fun MarriageScreen(onBack: () -> Unit, onSaved: () -> Unit) {
    var man by remember { mutableStateOf("") }
    var manMother by remember { mutableStateOf("") }
    var woman by remember { mutableStateOf("") }
    var womanMother by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ResultData?>(null) }
    fun badMother(t: String) = err && t.isNotBlank() && Abjad.value(t) == 0
    ScreenFrame("فال ازدواج ابجدی", onBack, onSaved, blurred = result != null) {
        IntroCard(PinkC, Icons.Filled.Favorite, "فال ازدواج و جفت بودن ستاره ها", "بر اساس ابجد نام شما و همسرتان")
        FormCard {
            Text("مرد", color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            TaleField(man, "نام مرد", Icons.Filled.Person, err && Abjad.value(man) == 0) { man = it }
            TaleField(manMother, "نام مادر مرد", Icons.Filled.Person, badMother(manMother)) { manMother = it }
            Text("زن", color = Color(0xFFB0176F), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            TaleField(woman, "نام زن", Icons.Filled.Person, err && Abjad.value(woman) == 0) { woman = it }
            TaleField(womanMother, "نام مادر زن", Icons.Filled.Person, badMother(womanMother), last = true) { womanMother = it }
            TaleButton("محاسبه فال", Icons.Filled.Favorite) {
                err = true
                val okNames = Abjad.value(man) > 0 && Abjad.value(woman) > 0
                val okMothers = (manMother.isBlank() || Abjad.value(manMother) > 0) &&
                    (womanMother.isBlank() || Abjad.value(womanMother) > 0)
                if (okNames && okMothers) {
                    val mm = if (manMother.isBlank()) "حوا" else manMother.trim()
                    val wm = if (womanMother.isBlank()) "حوا" else womanMother.trim()
                    val v1 = Abjad.value(man) + Abjad.value(mm)
                    val v2 = Abjad.value(woman) + Abjad.value(wm)
                    val z1 = Abjad.zodiac(v1); val z2 = Abjad.zodiac(v2)
                    result = ResultData("فال ازدواج ابجدی", listOf(
                        "مرد: ${man.trim()} (مادر: $mm)",
                        "عدد ابجد: $v1 ← برج ${z1.name}، عنصر ${Abjad.elements[z1.element]}",
                        "زن: ${woman.trim()} (مادر: $wm)",
                        "عدد ابجد: $v2 ← برج ${z2.name}، عنصر ${Abjad.elements[z2.element]}",
                        "مجموع ابجد دو طرف: ${v1 + v2}",
                        "جفت بودن ستاره‌ها: " + Abjad.compatibility(z1.element, z2.element)
                    ))
                }
            }
        }
        TipCard("اگر نام مادر را نمی‌دانید، آن را خالی بگذارید تا به‌جای آن از نام «حوا» استفاده شود.")
        Note()
    }
    ResultHost(result) { result = null }
}

@Composable
fun TipCard(text: String) {
    val shape = RoundedCornerShape(16.dp)
    Row(Modifier.fillMaxWidth().clip(shape).background(Color(0xFFFFF4D6))
        .border(1.dp, Color(0xFFD9A441), shape).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Info, null, tint = Color(0xFFB7791F), modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, color = Ink, fontSize = 13.sp, lineHeight = 21.sp)
    }
}

@Composable
fun InfoCard(title: String, lines: List<String>) {
    val shape = RoundedCornerShape(20.dp)
    Column(Modifier.fillMaxWidth().shadow(4.dp, shape).clip(shape).background(Color.White).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        lines.forEach { Text(it, color = Ink, fontSize = 14.sp, lineHeight = 23.sp) }
    }
}

@Composable
fun AstrologyScreen(onBack: () -> Unit, onSaved: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var mother by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ResultData?>(null) }
    ScreenFrame("طالع بینی ابجدی", onBack, onSaved, blurred = result != null) {
        IntroCard(BlueC, Icons.Filled.Star, "طالع و ستاره شما", "نام خود و نام مادر را وارد کنید")
        FormCard {
            TaleField(name, "نام شما", Icons.Filled.Person, err && Abjad.value(name) == 0) { name = it }
            TaleField(mother, "نام مادر", Icons.Filled.Person, err && Abjad.value(mother) == 0, last = true) { mother = it }
            TaleButton("محاسبه طالع", Icons.Filled.Star) {
                err = true
                val v1 = Abjad.value(name); val v2 = Abjad.value(mother)
                if (v1 > 0 && v2 > 0) {
                    val z = Abjad.zodiac(v1 + v2)
                    result = ResultData("طالع بینی ابجدی", listOf(
                        "نام ${name.trim()}: $v1",
                        "نام ${mother.trim()}: $v2",
                        "مجموع ابجد هر دو نام: ${v1 + v2}",
                        "برج: ${z.name} (ماه ${z.month})",
                        "عنصر: ${Abjad.elementInfo[z.element]}",
                        Abjad.qualityInfo[z.quality] ?: "",
                        "سیاره حاکم: ${z.planet} — روز خوش‌یُمن: ${Abjad.planetDay[z.planet]}",
                        "رنگ مناسب: ${z.color}",
                        "ویژگی‌ها: ${z.strengths}",
                        "نقاط ضعف: ${z.weaknesses}",
                        "در عشق و ازدواج: ${z.love}",
                        "مشاغل مناسب: ${z.career}"
                    ))
                }
            }
        }
        Note()
    }
    ResultHost(result) { result = null }
}

@Composable
fun NumbersScreen(onBack: () -> Unit, onSaved: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ResultData?>(null) }
    ScreenFrame("محاسبه ی ابجد نام", onBack, onSaved, blurred = result != null) {
        IntroCard(listOf(Color(0xFFF59E0B), Color(0xFFB45309)), Icons.Filled.Search,
            "معنا و عدد ابجدی نام", "نام یا کلمه را وارد کنید")
        FormCard {
            TaleField(text, "نام یا کلمه", Icons.Filled.Person, err && Abjad.value(text) == 0, last = true) { text = it }
            TaleButton("محاسبه عدد ابجد", Icons.Filled.Search) {
                err = true
                val v = Abjad.value(text)
                if (v > 0) {
                    val r = Abjad.reduce(v)
                    result = ResultData("اعداد ابجد", listOf(
                        text.trim(), "عدد ابجد: $v", "عدد تقلیل‌یافته: $r", "معنا: ${Abjad.numberMeaning[r]}"
                    ))
                }
            }
        }
        Note()
    }
    ResultHost(result) { result = null }
}

@Composable
fun SavedScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val items = remember { mutableStateListOf<SavedItem>().apply { addAll(SavedStore.load(ctx)) } }
    ScreenFrame("ذخیره‌شده‌ها", onBack, null) {
        if (items.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(top = 60.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(BookmarkIcon, null, tint = Purple.copy(alpha = 0.4f), modifier = Modifier.size(64.dp))
                Spacer(Modifier.height(12.dp))
                Text("هنوز چیزی ذخیره نکرده‌اید", color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("نتیجه فال یا طالع را با دکمه ذخیره نگه دارید", color = Sub, fontSize = 13.sp,
                    textAlign = TextAlign.Center)
            }
        } else {
            items.toList().forEach { item ->
                val shape = RoundedCornerShape(20.dp)
                Column(Modifier.fillMaxWidth().shadow(4.dp, shape).clip(shape).background(Color.White).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(item.kind, color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
                            modifier = Modifier.weight(1f))
                        IconButton(onClick = {
                            SavedStore.remove(ctx, item.id)
                            items.removeAll { it.id == item.id }
                        }) { Icon(Icons.Filled.Delete, "حذف", tint = Color(0xFFB3261E)) }
                    }
                    item.lines.forEach { Text(it, color = Ink, fontSize = 14.sp, lineHeight = 22.sp) }
                }
            }
        }
    }
}

@Composable
fun SoonScreen(onBack: () -> Unit, onSaved: () -> Unit) {
    ScreenFrame("به‌زودی", onBack, onSaved) {
        FormCard {
            Text("این بخش در حال آماده‌سازی است", color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
            Text("در نسخه‌های بعدی اضافه می‌شود.", color = Sub, fontSize = 14.sp)
        }
    }
}

@Composable
fun EducationScreen(onSaved: () -> Unit) {
    ScreenFrame("آموزش", null, onSaved) {
        IntroCard(listOf(Color(0xFF14B8A6), Color(0xFF0F766E)), Icons.Filled.Lock,
            "آموزش ابجد", "به‌زودی")
        InfoCard("در نسخه‌های بعدی", listOf(
            "بخش آموزش کامل و کاربردی ابجد در نسخه‌های بعدی اضافه می‌شود."
        ))
    }
}

@Composable
fun ContactScreen(onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val email = "Roohollahsafdary@gmail.com"
    ScreenFrame("ارتباط با ما", null, onSaved) {
        InfoCard("درباره برنامه", listOf(
            "این برنامه جنبه سرگرمی و فرهنگی دارد و نتایج آن مبنای علمی ندارد. برای تصمیم‌های مهم زندگی به آن تکیه نکنید."
        ))
        InfoCard("منابع", listOf(
            "• کشکول، شیخ بهایی",
            "• مجربات، ابوعلی سینا"
        ))
        FormCard {
            Text("ارتباط با ما", color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Text("نظر، پیشنهاد یا انتقاد خود را برای ما ایمیل کنید:", color = Ink, fontSize = 14.sp)
            Text(email, color = Sub, fontSize = 14.sp)
            TaleButton("ارسال ایمیل", Icons.Filled.Email) {
                try {
                    ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email")))
                } catch (e: Exception) {
                    Toast.makeText(ctx, "برنامه ایمیل پیدا نشد", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
