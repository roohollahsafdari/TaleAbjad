package com.taleabjad.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Purple = Color(0xFF4A1480)
val PurpleDark = Color(0xFF3B0F6E)
val PurpleLight = Color(0xFF6A1FA8)
val Ink = Color(0xFF2A1245)
val Sub = Color(0xFF6B5A80)
val Bg = Color(0xFFF3F0FA)

enum class Route { Home, Numbers, Marriage, Astrology, Soon }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = lightColorScheme(primary = Purple)) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var route by remember { mutableStateOf(Route.Home) }
    BackHandler(enabled = route != Route.Home) { route = Route.Home }
    when (route) {
        Route.Home -> HomeScreen { route = it }
        Route.Numbers -> NumbersScreen { route = Route.Home }
        Route.Marriage -> MarriageScreen { route = Route.Home }
        Route.Astrology -> AstrologyScreen { route = Route.Home }
        Route.Soon -> SoonScreen { route = Route.Home }
    }
}

@Composable
fun Header(title: String, tall: Boolean, onBack: (() -> Unit)? = null) {
    Box(
        Modifier.fillMaxWidth().height(if (tall) 140.dp else 84.dp)
            .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
            .background(Brush.linearGradient(listOf(PurpleDark, PurpleLight)))
    ) {
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.align(Alignment.Center))
        Image(painterResource(R.drawable.logo), null,
            Modifier.align(Alignment.CenterStart).padding(horizontal = 14.dp).size(if (tall) 76.dp else 52.dp))
        if (onBack != null) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, "بازگشت", tint = Color.White)
            }
        }
    }
}

@Composable
fun GradientIcon(colors: List<Color>, icon: ImageVector) {
    Box(Modifier.size(64.dp).clip(CircleShape).background(Brush.linearGradient(colors)),
        contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(34.dp))
    }
}

@Composable
fun MenuCard(title: String, sub: String, tint: Color, onClick: () -> Unit, icon: @Composable () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier.fillMaxWidth().shadow(6.dp, shape).clip(shape)
            .background(Brush.horizontalGradient(0f to tint, 0.45f to Color.White))
            .clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(Modifier.width(12.dp))
        Box(Modifier.width(1.dp).height(48.dp).background(Color(0x334A1480)))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
            Text(sub, color = Sub, fontSize = 12.sp)
        }
        Box(Modifier.size(36.dp).clip(CircleShape).background(Purple), contentAlignment = Alignment.Center) {
            Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = Color.White, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
fun HomeScreen(go: (Route) -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState())) {
        Header("طالع ابجد", tall = true)
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            MenuCard("بخش کاربردی اعداد ابجد", "معانی و تعبیر اعداد ابجد", Color(0xFFFDE6C8), { go(Route.Numbers) }) {
                Image(painterResource(R.drawable.icon_books), null, Modifier.size(64.dp))
            }
            MenuCard("فال ازدواج ابجدی", "سنجش تفأل و همدلی دو نام", Color(0xFFF9BFDC), { go(Route.Marriage) }) {
                GradientIcon(listOf(Color(0xFFE0197D), Color(0xFF8F0F6B)), Icons.Filled.Favorite)
            }
            MenuCard("طالع بینی ابجدی", "طالع و ستاره شما بر پایه نام", Color(0xFFCFB8FB), { go(Route.Astrology) }) {
                GradientIcon(listOf(Color(0xFF7B4DFF), Color(0xFF3A1FA8)), Icons.Filled.Star)
            }
            Image(painterResource(R.drawable.banner_quran), "استخاره قرآن کریم",
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).clickable { go(Route.Soon) },
                contentScale = ContentScale.FillWidth)
            MenuCard("دیگر برنامه های گروه", "برنامه های متنوع و جذاب", Color(0xFFB9ECC4), { go(Route.Soon) }) {
                Image(painterResource(R.drawable.icon_basket), null, Modifier.size(64.dp))
            }
        }
    }
}

@Composable
fun FormScreen(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Header(title, tall = false, onBack = onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

@Composable
fun Field(value: String, label: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
}

@Composable
fun ActionButton(text: String, onClick: () -> Unit) {
    Button(onClick, Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
        Text(text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ResultCard(title: String, lines: List<String>) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = Purple, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
        lines.forEach { Text(it, color = Ink, fontSize = 14.sp, lineHeight = 22.sp) }
    }
}

@Composable
fun Note() = Text("این برنامه جنبه سرگرمی و فرهنگی دارد و جایگزین مشاوره نیست.",
    color = Sub, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())

const val INVALID = "لطفاً نام را با حروف فارسی وارد کنید."

@Composable
fun MarriageScreen(onBack: () -> Unit) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<ResultData?>(null) }
    FormScreen("فال ازدواج ابجدی", onBack) {
        Field(a, "نام شما") { a = it }
        Field(b, "نام همسر آینده") { b = it }
        ActionButton("محاسبه فال") {
            val va = Abjad.value(a); val vb = Abjad.value(b)
            result = if (va == 0 || vb == 0) ResultData("نتیجه فال", listOf(INVALID)) else {
                val za = Abjad.zodiac(va); val zb = Abjad.zodiac(vb)
                ResultData("نتیجه فال", listOf(
                    "${a.trim()}: $va ← برج ${za.name}، عنصر ${Abjad.elements[za.element]}",
                    "${b.trim()}: $vb ← برج ${zb.name}، عنصر ${Abjad.elements[zb.element]}",
                    "مجموع ابجد دو نام: ${va + vb}",
                    Abjad.compatibility(za.element, zb.element)
                ))
            }
        }
        result?.let { ResultCard(it.title, it.lines) }
        Note()
    }
}

class ResultData(val title: String, val lines: List<String>)

@Composable
fun AstrologyScreen(onBack: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var mother by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<ResultData?>(null) }
    FormScreen("طالع بینی ابجدی", onBack) {
        Field(name, "نام شما") { name = it }
        Field(mother, "نام مادر") { mother = it }
        ActionButton("محاسبه طالع") {
            val v = Abjad.value(name) + Abjad.value(mother)
            result = if (Abjad.value(name) == 0 || Abjad.value(mother) == 0) ResultData("طالع شما", listOf(INVALID)) else {
                val z = Abjad.zodiac(v)
                ResultData("طالع شما", listOf(
                    "مجموع ابجد نام و نام مادر: $v",
                    "برج: ${z.name}",
                    "عنصر: ${Abjad.elements[z.element]}",
                    "ویژگی: ${z.trait}"
                ))
            }
        }
        result?.let { ResultCard(it.title, it.lines) }
        Note()
    }
}

@Composable
fun NumbersScreen(onBack: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<ResultData?>(null) }
    FormScreen("اعداد ابجد", onBack) {
        Field(text, "نام یا کلمه") { text = it }
        ActionButton("محاسبه عدد ابجد") {
            val v = Abjad.value(text)
            result = if (v == 0) ResultData("نتیجه", listOf(INVALID)) else {
                val r = Abjad.reduce(v)
                ResultData("نتیجه", listOf("عدد ابجد: $v", "عدد تقلیل‌یافته: $r", "معنا: ${Abjad.numberMeaning[r]}"))
            }
        }
        result?.let { ResultCard(it.title, it.lines) }
        Note()
    }
}

@Composable
fun SoonScreen(onBack: () -> Unit) {
    FormScreen("به‌زودی", onBack) {
        ResultCard("این بخش در حال آماده‌سازی است", listOf("در نسخه‌های بعدی اضافه می‌شود."))
    }
}
