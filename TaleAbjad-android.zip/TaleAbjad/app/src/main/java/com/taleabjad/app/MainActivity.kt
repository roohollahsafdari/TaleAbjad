package com.taleabjad.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

enum class Route { Home, Numbers, Marriage, Astrology, Saved, Soon, Education, Contact, Istikhara }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                TaleTheme { App() }
            }
        }
    }
}

@Composable
fun App() {
    var route by remember { mutableStateOf(Route.Home) }
    BackHandler(enabled = route != Route.Home) { route = Route.Home }
    val back = { route = Route.Home }
    val saved = { route = Route.Saved }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            when (route) {
                Route.Home -> HomeScreen { route = it }
                Route.Numbers -> NumbersScreen(back, saved)
                Route.Marriage -> MarriageScreen(back, saved)
                Route.Astrology -> AstrologyScreen(back, saved)
                Route.Saved -> SavedScreen(back)
                Route.Soon -> SoonScreen(back, saved)
                Route.Education -> EducationScreen(saved)
                Route.Contact -> ContactScreen(saved)
                Route.Istikhara -> IstikharaScreen(back, saved)
            }
        }
        if (route == Route.Home || route == Route.Education || route == Route.Contact) {
            TaleNavBar(route) { route = it }
        }
    }
}
