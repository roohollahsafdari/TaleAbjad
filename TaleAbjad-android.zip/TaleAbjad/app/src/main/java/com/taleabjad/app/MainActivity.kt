package com.taleabjad.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

enum class Route { Splash, Home, Numbers, Marriage, Astrology, Saved, Soon, Education, Contact, Istikhara }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                TaleTheme { App() }
            }
        }
    }
}

private fun isTab(r: Route) = r == Route.Home || r == Route.Education || r == Route.Contact

private fun titleOf(r: Route): String = when (r) {
    Route.Splash -> ""
    Route.Home -> "طالع ابجد"
    Route.Numbers -> "محاسبه ی ابجد نام"
    Route.Marriage -> "فال ازدواج ابجدی"
    Route.Astrology -> "طالع بینی ابجدی"
    Route.Saved -> "ذخیره‌شده‌ها"
    Route.Soon -> "به‌زودی"
    Route.Education -> "آموزش"
    Route.Contact -> "ارتباط با ما"
    Route.Istikhara -> if (IstikharaUi.item != null) "نتیجه استخاره" else "استخاره با قرآن کریم"
}

// One simple fade between pages; the top bar and bottom bar stay still.
private fun AnimatedContentTransitionScope<Route>.routeTransition(): ContentTransform =
    if (initialState == Route.Splash) {
        fadeIn(tween(450)) togetherWith fadeOut(tween(300))
    } else {
        fadeIn(tween(220, delayMillis = 60)) togetherWith fadeOut(tween(120))
    }

@Composable
fun App() {
    var route by remember { mutableStateOf(Route.Splash) }
    BackHandler(enabled = route != Route.Home && route != Route.Splash) { route = Route.Home }
    val back = { route = Route.Home }
    val saved = { route = Route.Saved }

    Box(Modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = route, modifier = Modifier.fillMaxSize(),
            transitionSpec = { routeTransition() }, label = "navigation"
        ) { r ->
            Box(
                Modifier.fillMaxSize().padding(
                    top = if (r == Route.Splash) 0.dp else TopBarHeight,
                    bottom = if (isTab(r)) NavBarHeight else 0.dp
                )
            ) {
                when (r) {
                    Route.Splash -> SplashScreen { route = Route.Home }
                    Route.Home -> HomeScreen {
                        if (it == Route.Istikhara) IstikharaUi.item = null
                        route = it
                    }
                    Route.Numbers -> NumbersScreen(back, saved)
                    Route.Marriage -> MarriageScreen(back, saved)
                    Route.Astrology -> AstrologyScreen(back, saved)
                    Route.Saved -> SavedScreen(back)
                    Route.Soon -> SoonScreen(back, saved)
                    Route.Education -> EducationScreen(saved)
                    Route.Contact -> ContactScreen(saved)
                    Route.Istikhara -> IstikharaScreen(back, saved)
                }
            }
        }
        AnimatedVisibility(
            visible = route != Route.Splash, modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(tween(300)), exit = fadeOut(tween(150))
        ) {
            TopBar(
                title = titleOf(route),
                showBack = !isTab(route),
                showSaved = route != Route.Saved,
                onBack = {
                    if (route == Route.Istikhara && IstikharaUi.item != null) IstikharaUi.item = null
                    else route = Route.Home
                },
                onSaved = { route = Route.Saved }
            )
        }
        AnimatedVisibility(
            visible = isTab(route), modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(250)), exit = fadeOut(tween(150))
        ) {
            TaleNavBar(route) { route = it }
        }
    }
}
