package com.taleabjad.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

enum class Route { Splash, Home, Numbers, Marriage, Astrology, Saved, Soon, Education, Contact, Istikhara }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                TaleTheme { App() }
            }
        }
    }
}

private fun depth(r: Route) = when (r) {
    Route.Splash -> 0
    Route.Home, Route.Education, Route.Contact -> 1
    else -> 2
}

private fun tabIndex(r: Route) = when (r) {
    Route.Home -> 0
    Route.Education -> 1
    Route.Contact -> 2
    else -> -1
}

private fun AnimatedContentTransitionScope<Route>.routeTransition(): ContentTransform {
    val from = initialState
    val to = targetState
    val start = AnimatedContentTransitionScope.SlideDirection.Start
    val end = AnimatedContentTransitionScope.SlideDirection.End
    return when {
        from == Route.Splash ->
            (fadeIn(tween(450)) + scaleIn(tween(450), initialScale = 0.92f)) togetherWith fadeOut(tween(250))
        tabIndex(from) >= 0 && tabIndex(to) >= 0 -> {
            val dir = if (tabIndex(to) > tabIndex(from)) start else end
            (slideIntoContainer(dir, tween(320), initialOffset = { it / 6 }) + fadeIn(tween(320))) togetherWith
                (slideOutOfContainer(dir, tween(320), targetOffset = { it / 6 }) + fadeOut(tween(160)))
        }
        depth(to) > depth(from) ->
            (slideIntoContainer(start, tween(340), initialOffset = { it / 4 }) + fadeIn(tween(340))) togetherWith
                (slideOutOfContainer(start, tween(340), targetOffset = { it / 8 }) + fadeOut(tween(200)))
        depth(to) < depth(from) ->
            (slideIntoContainer(end, tween(340), initialOffset = { it / 8 }) + fadeIn(tween(340))) togetherWith
                (slideOutOfContainer(end, tween(340), targetOffset = { it / 4 }) + fadeOut(tween(200)))
        else ->
            (fadeIn(tween(240, delayMillis = 90)) + scaleIn(tween(240, delayMillis = 90), initialScale = 0.92f)) togetherWith
                fadeOut(tween(90))
    }
}

@Composable
fun App() {
    var route by remember { mutableStateOf(Route.Splash) }
    BackHandler(enabled = route != Route.Home && route != Route.Splash) { route = Route.Home }
    val back = { route = Route.Home }
    val saved = { route = Route.Saved }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            AnimatedContent(
                targetState = route, modifier = Modifier.fillMaxSize(),
                transitionSpec = { routeTransition() }, label = "navigation"
            ) { r ->
                when (r) {
                    Route.Splash -> SplashScreen { route = Route.Home }
                    Route.Home -> HomeScreen { route = it }
                    Route.Numbers -> NumbersScreen(back, saved)
                    Route.Marriage -> MarriageScreen(back, saved)
                    Route.Astrology -> AstrologyScreen(back, saved)
                    Route.Saved -> SavedScreen(back)
                    Route.Soon -> SoonScreen(back, saved)
                    Route.Education -> EducationScreen(saved)
                    Route.Contact -> ContactScreen(saved)
                    Route.Istikhara -> IstikharaScreen(back, saved)
                }
            }
        }
        AnimatedVisibility(
            visible = route == Route.Home || route == Route.Education || route == Route.Contact,
            enter = slideInVertically(tween(300)) { it } + fadeIn(tween(300)),
            exit = slideOutVertically(tween(250)) { it } + fadeOut(tween(200))
        ) {
            TaleNavBar(route) { route = it }
        }
    }
}
