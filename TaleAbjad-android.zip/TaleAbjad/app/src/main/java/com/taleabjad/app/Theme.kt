package com.taleabjad.app

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

val Purple = Color(0xFF4A1480)
val PurpleDark = Color(0xFF3B0F6E)
val PurpleLight = Color(0xFF6A1FA8)
val Gold = Color(0xFFD9A441)
val Ink = Color(0xFF2A1245)
val Sub = Color(0xFF6B5A80)
val Bg = Color(0xFFF3F0FA)

val VF = FontFamily(
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_medium, FontWeight.Medium),
    Font(R.font.vazirmatn_bold, FontWeight.Bold),
    Font(R.font.vazirmatn_extrabold, FontWeight.ExtraBold)
)

private fun vazirTypography(): Typography {
    val d = Typography()
    return Typography(
        displayLarge = d.displayLarge.copy(fontFamily = VF),
        displayMedium = d.displayMedium.copy(fontFamily = VF),
        displaySmall = d.displaySmall.copy(fontFamily = VF),
        headlineLarge = d.headlineLarge.copy(fontFamily = VF),
        headlineMedium = d.headlineMedium.copy(fontFamily = VF),
        headlineSmall = d.headlineSmall.copy(fontFamily = VF),
        titleLarge = d.titleLarge.copy(fontFamily = VF),
        titleMedium = d.titleMedium.copy(fontFamily = VF),
        titleSmall = d.titleSmall.copy(fontFamily = VF),
        bodyLarge = d.bodyLarge.copy(fontFamily = VF),
        bodyMedium = d.bodyMedium.copy(fontFamily = VF),
        bodySmall = d.bodySmall.copy(fontFamily = VF),
        labelLarge = d.labelLarge.copy(fontFamily = VF),
        labelMedium = d.labelMedium.copy(fontFamily = VF),
        labelSmall = d.labelSmall.copy(fontFamily = VF)
    )
}

@Composable
fun TaleTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Purple, onPrimary = Color.White,
            primaryContainer = Color(0xFFEBDDFB), onPrimaryContainer = Ink,
            secondary = Color(0xFFE0197D), surface = Color.White, background = Bg,
            onSurface = Ink, outline = Color(0xFFB9A8D0)
        ),
        typography = vazirTypography(),
        shapes = Shapes(
            small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(16.dp),
            large = RoundedCornerShape(28.dp)
        )
    ) {
        ProvideTextStyle(TextStyle(fontFamily = VF), content)
    }
}
