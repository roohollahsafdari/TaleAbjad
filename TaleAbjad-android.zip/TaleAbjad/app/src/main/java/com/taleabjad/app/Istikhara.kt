package com.taleabjad.app

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.delay

object IstikharaUi {
    var item by mutableStateOf<IstikharaItem?>(null)
}

class IstikharaItem(
    val page: Int, val sura: Int, val suraName: String, val aya: Int,
    val arabic: String, val persian: String,
    val general: String, val overall: String, val marriage: String, val trade: String
)

object IstikharaData {
    private var cache: List<IstikharaItem>? = null

    fun load(ctx: Context): List<IstikharaItem> {
        cache?.let { return it }
        val text = ctx.assets.open("estekhare.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val arr = JSONArray(text)
        val list = ArrayList<IstikharaItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(IstikharaItem(
                o.getInt("p"), o.getInt("s"), o.getString("sn"), o.getInt("a"),
                o.getString("ar"), o.getString("fa"),
                o.getString("g"), o.getString("o"), o.getString("m"), o.getString("t")
            ))
        }
        cache = list
        return list
    }
}

@Composable
fun IstikharaScreen(onBack: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val topics = listOf("عمومی", "ازدواج", "تجارت")
    var topic by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    val item = IstikharaUi.item
    var resultTopic by remember { mutableStateOf(0) }
    val holder = remember { arrayOfNulls<IstikharaItem>(1) }
    item?.let { holder[0] = it }

    LaunchedEffect(loading) {
        if (loading) {
            delay(3000)
            IstikharaUi.item = IstikharaData.load(ctx).random()
            resultTopic = topic
            loading = false
        }
    }
    BackHandler(enabled = item != null) { IstikharaUi.item = null }

    val stage = when {
        loading -> 1
        item != null -> 2
        else -> 0
    }
    AnimatedContent(
        targetState = stage, modifier = Modifier.fillMaxSize(),
        transitionSpec = {
            fadeIn(tween(220, delayMillis = 60)) togetherWith fadeOut(tween(120))
        },
        label = "istikhara"
    ) { s ->
        when (s) {
            1 -> LoadingView(onBack, onSaved)
            2 -> holder[0]?.let { ResultView(it, topics[resultTopic], resultTopic, { IstikharaUi.item = null }, onSaved) }
            else -> ScreenFrame("استخاره با قرآن کریم", onBack, onSaved) {
                Image(painterResource(R.drawable.banner_quran), "استخاره قرآن کریم",
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.FillWidth)
                FormCard {
                    Text("موضوع استخاره را انتخاب کنید", color = Purple, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        topics.forEachIndexed { i, name ->
                            FilterChip(
                                selected = topic == i, onClick = { topic = i },
                                label = { Text(name) }, modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFEBDDFB), selectedLabelColor = Purple
                                )
                            )
                        }
                    }
                    Text("نیت کنید، با آرامش صلوات بفرستید و سپس دکمه را بزنید.", color = Sub, fontSize = 13.sp)
                    TaleButton("استخاره", null) { loading = true }
                }
                Note()
            }
        }
    }
}

@Composable
fun LoadingView(onBack: () -> Unit, onSaved: () -> Unit) {
    var started by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { started = true }
    val p by animateFloatAsState(if (started) 1f else 0f, tween(3000, easing = LinearEasing), label = "progress")
    val pulse = rememberInfiniteTransition(label = "pulse")
    val sc by pulse.animateFloat(0.88f, 1.08f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "scale")
    val phrase = when {
        p < 0.34f -> "نیت کنید"
        p < 0.67f -> "صلوات بفرستید"
        else -> "قرآن در حال گشوده شدن است"
    }
    ScreenFrame("استخاره با قرآن کریم", onBack, onSaved) {
        Column(Modifier.fillMaxWidth().padding(top = 70.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(200.dp).shadow(10.dp, CircleShape).background(Color.White, CircleShape),
                contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { p }, modifier = Modifier.size(170.dp), strokeWidth = 8.dp,
                    color = Purple, trackColor = Color(0xFFE3D5F5), strokeCap = StrokeCap.Round
                )
                Icon(BookIcon, null, tint = Gold, modifier = Modifier.size(68.dp).scale(sc))
            }
            Spacer(Modifier.height(28.dp))
            Text("در حال استخاره...", color = Purple, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text(phrase, color = Sub, fontSize = 16.sp)
        }
    }
}

private class Verdict(val from: Color, val to: Color, val icon: ImageVector)

private fun verdictOf(general: String): Verdict = when {
    general.contains("هرگز") -> Verdict(Color(0xFF7F1D1D), Color(0xFFB91C1C), Icons.Filled.Close)
    general.contains("نده") -> Verdict(Color(0xFFB91C1C), Color(0xFFEF4444), Icons.Filled.Close)
    general.contains("حتما") -> Verdict(Color(0xFF047857), Color(0xFF10B981), Icons.Filled.Check)
    general.contains("بده") -> Verdict(Color(0xFF059669), Color(0xFF34D399), Icons.Filled.Check)
    else -> Verdict(Color(0xFFB45309), Color(0xFFF59E0B), Icons.Filled.Warning)
}

@Composable
fun ResultView(item: IstikharaItem, topicName: String, topicIndex: Int, onClose: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    var saved by remember(item) { mutableStateOf(false) }
    val v = verdictOf(item.general)
    val detail = when (topicIndex) { 1 -> item.marriage; 2 -> item.trade; else -> item.overall }
    ScreenFrame("نتیجه استخاره", onClose, onSaved, scrollbar = true) {
        // 1) verdict
        Column(
            Modifier.fillMaxWidth().shadow(8.dp, RoundedCornerShape(28.dp)).clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(v.from, v.to))).padding(vertical = 26.dp, horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(Modifier.size(72.dp).background(Color.White.copy(alpha = 0.25f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(v.icon, null, tint = Color.White, modifier = Modifier.size(44.dp))
            }
            Text("نتیجه استخاره ($topicName)", color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp)
            Text(item.general, color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center, lineHeight = 50.sp)
        }
        // 2) tafsir
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(v.to.copy(alpha = 0.10f))
                .border(2.dp, v.to, RoundedCornerShape(24.dp)).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("تفسیر استخاره", color = v.from, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Text(detail, color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold, lineHeight = 36.sp)
        }
        // 3) ayah
        Column(
            Modifier.fillMaxWidth().shadow(4.dp, RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp))
                .background(Color.White).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("آیه راهنما", color = Sub, fontSize = 13.sp)
            Text(item.arabic, color = Purple, fontFamily = FontFamily.Serif, fontSize = 24.sp,
                lineHeight = 44.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x334A1480)))
            Text(item.persian, color = Ink, fontSize = 15.sp, lineHeight = 26.sp)
            Text("سوره ${item.suraName}، آیه ${item.aya} (صفحه ${item.page})", color = Sub, fontSize = 12.sp)
        }
        // 4) actions
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = {
                    SavedStore.add(ctx, "استخاره — $topicName", listOf(
                        item.arabic,
                        "سوره ${item.suraName}، آیه ${item.aya} (صفحه ${item.page})",
                        item.persian, "نتیجه: ${item.general}", detail
                    ))
                    saved = true
                    Toast.makeText(ctx, "ذخیره شد", Toast.LENGTH_SHORT).show()
                },
                enabled = !saved, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Purple)
            ) {
                Icon(BookmarkIcon, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (saved) "ذخیره شد" else "ذخیره", fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = onClose, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Filled.Refresh, null, Modifier.size(18.dp), tint = Purple)
                Spacer(Modifier.width(6.dp))
                Text("استخاره مجدد", color = Purple, fontWeight = FontWeight.Bold)
            }
        }
        Text("این نتیجه جنبه تفأل دارد و حکم شرعی نیست؛ در کارهای مهم با افراد آگاه مشورت کنید.",
            color = Sub, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}
