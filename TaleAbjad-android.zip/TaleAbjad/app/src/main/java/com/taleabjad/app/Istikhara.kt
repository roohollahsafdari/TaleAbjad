package com.taleabjad.app

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

class IstikharaItem(
    val page: Int, val sura: Int, val suraName: String, val aya: Int,
    val arabic: String, val persian: String,
    val general: String, val overall: String, val marriage: String, val trade: String
)

object IstikharaData {
    private var cache: List<IstikharaItem>? = null

    fun load(ctx: Context): List<IstikharaItem> {
        cache?.let { return it }
        val text = ctx.assets.open("estekhare.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val arr = JSONArray(text)
        val list = ArrayList<IstikharaItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(IstikharaItem(
                o.getInt("p"), o.getInt("s"), o.getString("sn"), o.getInt("a"),
                o.getString("ar"), o.getString("fa"),
                o.getString("g"), o.getString("o"), o.getString("m"), o.getString("t")
            ))
        }
        cache = list
        return list
    }
}

@Composable
fun IstikharaScreen(onBack: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val topics = listOf("عمومی", "ازدواج", "تجارت")
    var topic by remember { mutableStateOf(0) }
    var result by remember { mutableStateOf<ResultData?>(null) }
    ScreenFrame("استخاره با قرآن کریم", onBack, onSaved, blurred = result != null) {
        Image(painterResource(R.drawable.banner_quran), "استخاره قرآن کریم",
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)), contentScale = ContentScale.FillWidth)
        FormCard {
            Text("موضوع استخاره را انتخاب کنید", color = Purple, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                topics.forEachIndexed { i, name ->
                    FilterChip(
                        selected = topic == i, onClick = { topic = i },
                        label = { Text(name) }, modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFEBDDFB), selectedLabelColor = Purple
                        )
                    )
                }
            }
            Text("نیت کنید، با آرامش صلوات بفرستید و سپس دکمه را بزنید.", color = Sub, fontSize = 13.sp)
            TaleButton("شروع استخاره", Icons.Filled.PlayArrow) {
                val item = IstikharaData.load(ctx).random()
                val detail = when (topic) { 1 -> item.marriage; 2 -> item.trade; else -> item.overall }
                result = ResultData(
                    "استخاره — " + topics[topic],
                    listOf(
                        "سوره ${item.suraName}، آیه ${item.aya} (صفحه ${item.page})",
                        item.persian,
                        "نتیجه: ${item.general}",
                        detail,
                        "این نتیجه جنبه تفأل دارد و حکم شرعی نیست؛ در کارهای مهم با افراد آگاه مشورت کنید."
                    ),
                    quote = item.arabic
                )
            }
        }
        Note()
    }
    ResultHost(result) { result = null }
}
